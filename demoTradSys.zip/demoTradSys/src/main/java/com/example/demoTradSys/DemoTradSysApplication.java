package com.example.demoTradSys;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTradSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTradSysApplication.class, args);
	}

}
