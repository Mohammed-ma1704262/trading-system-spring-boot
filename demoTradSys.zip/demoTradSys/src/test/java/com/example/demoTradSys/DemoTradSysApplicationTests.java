package com.example.demoTradSys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTradSysApplicationTests {

	@Test
	void contextLoads() {
	}

}
